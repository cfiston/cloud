# Ambari API Examples

This is a collection of Ambari API examples, using python & ipython Notebook to show them.

How to use this:

- Browse a read-only verison of the notebook [here](http://nbviewer.ipython.org/github/seanorama/ambari-bootstrap/blob/master/api-examples/).
- Download the notebook and use [your own ipython Notebook](http://ipython.org/install.html).

For a bit of inception:

- Run your own ipython notebook from within Ambari!: https://github.com/randerzander/ipython-stack

