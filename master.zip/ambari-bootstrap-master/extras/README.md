## Variety of scripts to help with my use of HDP & Ambari

Disclaimer: These are rough scripts thrown together for my general use.

Mostly tested on small clusters to demonstrate functionality or while teaching Hadoop such as in my Hadoop Masterclasses.

